Cognome e Nome: Goumri Choaib
Data: 6/12/24

Breve descrizione riassuntiva delle modifiche: 


Nel progetto GOUMRICHOAIB_Bean sono stati corretti errori nei nomi delle costanti e metodi, migliorata la gestione delle date utilizzando LocalDateTime e aggiunta una verifica per gestire gli oggetti null. Inoltre, è stata implementata una HashMap per tracciare le chiamate ai metodi e migliorata la gestione degli errori nel client JMS.

Nel progetto GOUMRICHOAIB_Client, è stata rimossa un'annotation inutile e corretta la gestione dell'input per i valori float.

Nel progetto GOUMRICHOAIB_JMSClient, è stata risolta una mancata inizializzazione nel metodo createContext().

Le modifiche hanno migliorato la coerenza, la gestione degli errori e l'efficienza del progetto, inoltre, in tutti i progetti sono state aggiunte delle ";" mancanti che erano necessarie per il corretto funzionamento del codice. 


------------------------------
MODIFICHE
PROGETTO: GOUMRICHOAIB_Bean 

FILE: Libro

Linea 18: String TROVA_PER_TITOLO , modifica in Libro.trovaPerTitolo

Linea 38: private LocalDateTime e non date

FILE: DatabasePopulator

Linea 57: vi era metodo scritto "remove" al posto di rimuoviLibro

FILE: LibroEJB

Linea 60: corretta la scritta titolo -> era "titloto"

Linea : aggiunta verifica dell'oggetto null, per facilitare la stampa di errore del JMS Client

FILE: CounterInterceptor

Linea 19: aggiunta di un hashmap per tenere traccia di tutte le chiamate, in precedenza avevo interpretato male la traccia, tenendo traccia solo dell'ultimo metodo chiamato.

Linea 24 : aggiunta metodo put per inserire il metodo e il numero di volte chiamato.

Linea 25 : aggiunta di stampa


FILE: VenditaInterceptor

Linea 19: correzione nome Annotation da @VenditaInterceptor a @VenditaRomanzo

Linea 35 : modifica da getTipologia() a getTipoLibro


FILE: VenditaNotification

Linea 14: Rimozione della annotation e inserimento della classe.

Linea 35 : modifica da getTipologia() a getTipoLibro


FILE: LibroMDB

Linea 22: aggiunta annotation @Override.

Linea 31 : mancato passaggio di parametro id

Linea 33 : vi era metodo scritto "remove" al posto di rimuoviLibro

------------------------------

PROGETTO: GOUMRICHOAIB_Client 
FILE: LibroClient
Linea 26: rimozione annotation @Inject -> inutile
Linea 26: mancata aggiunta dicitura "new"
Linea 42: aggiunta di Float ad f , e il metodo scanner adatto per i float, 


------------------------------

PROGETTO: GOUMRICHOAIB_JMSClient
FILE: LibroJMSClient
Linea 43 : mancato assegnamento oggetto al metodo createContext();



